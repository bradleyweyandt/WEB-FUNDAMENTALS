function add1(id){
    var countElement = document.querySelector(`#${id}`)
    countElement.innerText++
    // console.log(count);
}
