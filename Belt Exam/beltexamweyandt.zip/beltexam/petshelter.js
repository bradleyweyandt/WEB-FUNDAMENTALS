function hide(element) {
    element.remove();
}
function add1(id){
    var countElement = document.querySelector(`#${id}`)
    countElement.innerText++
    // console.log(count);
}
function pickPet(element){
    console.log("You are looking for " + element.value);
    pet = element.value;
    alert("You are look for a: " + pet)
}